"""
URL configuration for cafeproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# Django の管理サイトを利用するために必要なモジュールをインポートする文
from django.contrib import admin
from django.urls import path
# cafeappフォルダーにあるviews.pyをインポート
from cafeapp import views

urlpatterns = [
    # Django の管理サイト（Admin Interface）にアクセスするための URL パターンを定義
    path("admin/", admin.site.urls),
    path('reservation/list/', views.ReservationListView.as_view(), name="reservation_list"),
    path('reservation/detail/<int:pk>', views.ReservationDetailView.as_view(), name='reservation_detail'),
    path('calendar/', views.CalendarView.as_view(), name='calendar'),  
     # 日にちが指定された場合
    path('calendar/<int:year>/<int:month>/<int:day>/', views.CalendarView.as_view(), name='calendar'), 
    path('reserve/<int:year>/<int:month>/<int:day>/<int:hour>', views.ReservationView.as_view(), name='reserve'),
    path('reserve_complete/<str:datetime>/<str:customer_name>', views.ReserveCompleteView.as_view(), name='reserve_complete'),
    path('',views.TopView.as_view(), name='top'),
]

