# Djangoのモデル機能を使うために必要なインポート文
# Djangoのモデルはデータベースと連携してデータを管理するためのクラスを定義するのに使用される
from django.db import models
# Djangoフレームワークで使われるtimezoneモジュールをインポート
# 日時に関する処理をタイムゾーン対応で行うための機能
from django.utils import timezone

# 予約情報を入れるReservationモデルを定義
# models.Modelを継承している
class Reservation(models.Model):
    # 自動的に数字連番で登録されるフィールド。
    # 同じ番号のデータは存在しないため、データの特定に使う
    id = models.AutoField(primary_key=True)
    # 予約者の氏名。最大文字列長は50
    customer_name = models.CharField(max_length=50)
    # 予約者の電話番号。最大文字列長は11
    phone_number = models.CharField(max_length=11)
    # 予約日時
    # 初期値はデータ保存した日時
    datetime = models.DateTimeField(default=timezone.now)
    # 利用終了日時を表す
    # 初期値はデータ保存した日時（エラー防止のため初期値を設定）
    end_datetime = models.DateTimeField(default=timezone.now)
    # 滞在時間。1時間なら1、2時間なら2が入る。
    # PositiveIntegerField；正の数のフィールド、default=0：初期値は0
    stay_times = models.PositiveIntegerField(default=0)
    # 備考欄。最大200文字、空欄OK
    remarks = models.CharField(max_length=200,blank=True)
    # 事前注文の有無を示す。注文なし=0、注文あり=1
    is_preorder = models.PositiveIntegerField(default=0)

    # 予約IDを文字列として返す。
    def __str__(self):
        return str(self.id)

# メニュー情報を入れるMenuモデルを定義
# models.Modelを継承している
class Menu(models.Model):
    # メニュー名。最大文字列長は80
    menu_name = models.CharField(max_length=80)
    # メニューの価格（正の整数のみ）
    price = models.PositiveIntegerField(default=0)
    #新規作成・編集完了時のリダイレクト先
    def get_absolute_url(self):
        return reverse('employee_top')

# 注文されたメニューの情報を入れるMenuSelectedモデルを定義
# models.Modelを継承している
class MenuSelected(models.Model):
    # Menuとの関連付け。選択されたMenuのidを格納
    # 多対1の関係
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE)  
    # 予約との関連付け。Reservationのidを格納
    # 多対1の関係
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE)
    # メニューの数量（正の整数のみ）
    quantity = models.PositiveIntegerField(default=0)