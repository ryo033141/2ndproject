from cafeapp.models import Menu

menu_items = [
    {"menu_name": "ティー", "price": 350 },
    {"menu_name": "カフェラテ", "price": 390 },
    {"menu_name": "ブレンドコーヒー", "price": 300 },
    {"menu_name": "アイスコーヒー", "price": 300 },
    {"menu_name": "アイスティー", "price": 310 },
    {"menu_name": "タピオカミルクティー", "price": 550 },
    {"menu_name": "ジャーマンドッグ", "price": 220 },
    {"menu_name": "野菜サンド", "price": 220 },
    {"menu_name": "トースト", "price": 260 },
    {"menu_name": "チーズトースト", "price": 190 },
    {"menu_name": "大豆ミートサンド", "price": 250 },
    {"menu_name": "サンドウィッチ", "price": 350 },
    {"menu_name": "ジンジャーマンクッキー", "price": 150 },
    {"menu_name": "ホットアップルティー", "price": 400 },
    {"menu_name": "グラタンポットパイ", "price": 500 },
]

# 一括でデータを作成
for item in menu_items:
    Menu.objects.create(menu_name=item["menu_name"], price=item["price"])