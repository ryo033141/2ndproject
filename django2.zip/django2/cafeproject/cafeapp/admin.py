# Djangoの管理画面機能を利用するためのインポート文
from django.contrib import admin
# models.pyからReservationクラス、Menuクラス、MenuSelectedクラスをインポート
from .models import Reservation, Menu, MenuSelected

# ReservationAdmin クラスは、admin.ModelAdmin を継承している
# Djangoの管理画面の設定を管理するためのクラス
class ReservationAdmin(admin.ModelAdmin):
    # 管理画面でのモデルの一覧表示時に表示するフィールドを指定する設定
    # 予約ID、氏名、予約日時、事前注文の有無を表示する
    list_display = ('id', 'customer_name', 'datetime', 'is_preorder')
    # 管理画面で検索ボックスを使って検索可能にしたいフィールドを指定
    search_fields = ('customer_name','datetime')

# Djangoの管理画面にReservationモデルを登録するための命令
admin.site.register(Reservation,ReservationAdmin)

# MenuAdminクラスは、admin.ModelAdmin を継承している
# Djangoの管理画面の設定を管理するためのクラス
class MenuAdmin(admin.ModelAdmin):
    # 管理画面でのモデルの一覧表示時に表示するフィールドを指定する設定
    # メニュー名、価格の有無を表示する
    list_display = ('menu_name','price', )
    # 管理画面で検索ボックスを使って検索可能にしたいフィールドを指定
    search_fields = ('menu_name', )

# MenuSelectedAdminクラスは、admin.ModelAdmin を継承している
# Djangoの管理画面の設定を管理するためのクラス
class MenuSelectedAdmin(admin.ModelAdmin):
    # 管理画面でのモデルの一覧表示時に表示するフィールドを指定する設定
    # メニューID、予約ID、メニューの個数の有無を表示する
    list_display = ('menu', 'reservation', 'quantity',)

# Djangoの管理画面にMenuモデルを登録するための命令
admin.site.register(Menu,MenuAdmin)
# Djangoの管理画面にMenuSelectedモデルを登録するための命令
admin.site.register(MenuSelected, MenuSelectedAdmin)