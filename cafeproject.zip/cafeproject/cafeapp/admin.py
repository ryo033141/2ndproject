from django.contrib import admin
from .models import Reservation, Menu, MenuSelected

class ReservationAdmin(admin.ModelAdmin):
    list_display = ('id','customer_name','datetime', 'is_preorder')
    search_fields = ('customer_name','datetime')
    
admin.site.register(Reservation, ReservationAdmin)


class MenuAdmin(admin.ModelAdmin):
    list_display = ('menu_name', 'price', )
    search_fields = ('menu_name',)
    
class MenuSelectedAdmin(admin.ModelAdmin):
    list_display = ('menu', 'reservation', 'quantity',)

admin.site.register(Menu, MenuAdmin)
admin.site.register(MenuSelected, MenuSelectedAdmin)