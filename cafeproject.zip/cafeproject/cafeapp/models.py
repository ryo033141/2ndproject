from django.db import models
from django.utils import timezone 
from django.urls import reverse  #Try 3-3で追加

# 予約情報を保存するモデル
class Reservation(models.Model):
    id = models.AutoField(primary_key=True)  # 自動的に連番で一意のIDを作成する
    customer_name = models.CharField(max_length=50)  # 顧客名を最大50文字で保存
    phone_number = models.CharField(max_length=11)  # 電話番号（最大11桁）を保存
    datetime = models.DateTimeField(default=timezone.now)  # 来店日時。デフォルトで現在の日時
    end_datetime = models.DateTimeField(default=timezone.now)  # 利用終了時間。
    stay_times = models.PositiveIntegerField(default=0)  # 滞在時間（正の整数のみ許可）
    remarks = models.CharField(max_length=200, blank=True)  # 備考欄（空欄も許可）
    is_preorder = models.PositiveIntegerField(default=0)  # 事前注文の有無。「有」=1、「無」=0

    def __str__(self):
        """予約のIDを文字列として返す。管理画面やデバッグ時に便利"""
        return str(self.id)


class Menu(models.Model):
    menu_name = models.CharField(max_length=80)
    price = models.PositiveIntegerField(default=0)
    #Try3-3
    #新規作成・編集完了時のリダイレクト先
    def get_absolute_url(self):
        return reverse('employee_top')
    
class MenuSelected(models.Model):
    menu = models.ForeignKey(Menu, on_delete=models.CASCADE)  # 多対1の関係
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=0)

