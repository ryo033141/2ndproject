from typing import Any
from django import forms
from .models import Menu 

# 予約フォームの定義
class ReservationForm(forms.Form):
    """予約フォームの定義。お客様が予約の際に入力する基本情報を管理"""
    customer_name = forms.CharField(max_length=50, label='お名前')
    phone_number = forms.CharField(max_length=15, label='電話番号(ハイフンなし)')
    stay_times = forms.IntegerField(label='滞在時間(1時間単位)')
    remarks = forms.CharField(max_length=200, label='備考', required=False)  # 空欄でも予約できるよう、required=Falseとした。
    is_preorder = forms.IntegerField(label='事前注文(有り=1、無し=0で記入)')  # 事前注文の有無を表す。「有」=1,「無」=0


# 事前注文用のメニュー選択フォーム
class MenuSelectedForm(forms.Form):
    """事前注文用のメニュー選択フォーム。各メニューとその注文数を入力"""
    def __init__(self, *args, **kwargs):
        """このフォームが呼び出された際に最初に実行される処理"""
        super().__init__(*args, **kwargs)
        menus = Menu.objects.all()  # 全てのメニューを取得してフォームに反映
        for menu in menus:
            # 各メニューに対応する数量入力フィールドを動的に作成
            self.fields[f'{menu.menu_name}'] = forms.IntegerField(
                label=menu.menu_name,  # メニュー名をラベルとして使用
                min_value=0,  # 最低値は0（0以上の数値のみ許可）
                initial=0,  # デフォルト値は0
                required=False  # 数量が入力されていない場合は無視
            )