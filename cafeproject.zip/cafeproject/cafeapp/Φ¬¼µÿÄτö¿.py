from django.shortcuts import render
from django.views.generic import ListView, DetailView, View 
from django.utils.timezone import localtime, make_aware 
from .models import Reservation
from datetime import datetime, date, timedelta, time


SEAT_NUM = 5  # 席の定数

class ReservationListView(ListView): 
    model = Reservation  # Reservationモデルのデータを表示
    paginate_by = 20  # 1ページに表示する予約の数を20件に設定

class ReservationDetailView(DetailView): 
    model = Reservation  # Reservationモデルを使用

class CalendarView(View):  
    def get(self, request, *args, **kwargs):
        """カレンダー画面の表示処理を行う。予約可能な日付と時間を確認できる画面を生成。"""
        today = date.today()  # 今日の日付を取得→12/9

        start_date = today  # start_dateに12/9を代入

        # 1週間分の日付リストを作成（start_dateから7日間）
        days = [start_date + timedelta(days=day) for day in range(7)]  # [12/9, 12/10, 12/11, 12/12, 12/13, 12/14, 12/15]
        start_day = days[0]  # 1週間の最初の日、12/9を代入
        end_day = days[-1]  # 1週間の最後の日、　12/15を代入

        calendar = {}  # カレンダー表示用のデータ構造。まだ空
        booked_seat = {}  # 各時間帯の予約済み席数を管理するデータ構造。まだ空

        # 営業時間の範囲を設定（10時から16時）
        for hour in range(10, 17):
            row_calendar = {}
            row_seat = {}
            # 各日付に対して、カレンダーと予約情報を初期化
            for day in days:
                row_calendar[day] = True  # 初期値は予約可能（True）
                row_seat[day] = 0  # 予約席数を0に設定
            calendar[hour] = row_calendar  # カレンダーに時間ごとのデータを追加
            booked_seat[hour] = row_seat  # 席情報を初期化

        # 予約対象期間の開始時刻と終了時刻を作成
        start_time = make_aware(datetime.combine(start_day, time(hour=10, minute=0)))  # yyyy:mm:dd:10:00
        end_time = make_aware(datetime.combine(end_day, time(hour=17, minute=0)))  # yyyy:mm:dd:17:00(start_timeの6日後の営業終了時間)

        # 予約データをフィルタリングして、指定の期間内の予約を取得
        reservation_data = Reservation.objects.filter(datetime__gte=start_time, end_datetime__lte=end_time)

        # 各日時の予約数をカウントし、満席であれば予約不可能に設定
        for reservation in reservation_data:
            local_time = localtime(reservation.datetime)  # 現地時間に変換
            reservation_date = local_time.date()  # 日付を取得
            reservation_hour = local_time.hour  # 時間を取得
            # 予約席数がまだ満席でない場合、予約数を増やす
            if booked_seat[reservation_hour][reservation_date] < SEAT_NUM:
                booked_seat[reservation_hour][reservation_date] += 1
            # 予約席数が最大に達した場合は、その日時の予約を不可にする
            if booked_seat[reservation_hour][reservation_date] == SEAT_NUM:
                calendar[reservation_hour][reservation_date] = False  # 満席で予約不可（False）

        # カレンダーの情報をテンプレートに渡して表示
        return render(request, 'cafeapp/calendar.html', {
            'calendar': calendar,  # カレンダー情報
            'days': days,  # 表示する1週間の日付
            'start_day': start_day,  # 週の最初の日
            'end_day': end_day,  # 週の最後の日
            'before': days[0] - timedelta(days=7),  # 1週間前へのリンク
            'next': days[-1] + timedelta(days=1),  # 1週間後へのリンク
            'today': today,  # 今日の日付
        })