# Djangoの管理画面機能を利用するためのインポート文
from django.contrib import admin
# models.pyからReservationクラスをインポート
from .models import Reservation

# Djangoの管理画面にReservationモデルを登録するための命令
admin.site.register(Reservation)