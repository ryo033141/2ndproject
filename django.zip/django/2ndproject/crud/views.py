# Django フレームワークでビュー関数を作成する際によく使用されるインポート文
from django.shortcuts import render
from django.views.generic import TemplateView, ListView, DetailView
"""
商品を新規作成するためのViewを追加
新規作成に特化したCreateViewクラス
既存のモデルオブジェクトを編集するフォームを表示し、更新内容を保存するUpdateViewクラス
既存のモデルオブジェクトを削除するためのDeleteViewクラスをインポート
"""
from django.views.generic.edit import CreateView, UpdateView, DeleteView
# models.pyからReservationクラスをインポート
from .models import Reservation
# 削除成功時に遷移するURLを指定するためのインポート文
from django.urls import reverse_lazy
# Djangoアプリケーションにログイン・ログアウト機能を組み込むためのインポート文
from django.contrib.auth.views import LoginView, LogoutView
# ログインしていなければアクセスできないようにするためのインポート文
from django.contrib.auth.mixins import LoginRequiredMixin
# Djangoで提供されているログイン用の組み込みフォームを使用するためのインポート文
from django.contrib.auth.forms import AuthenticationForm

# Logout_completeViewクラスは TemplateView を継承し、指定したテンプレート (logout_complete.html) を表示する
class Logout_completeView(TemplateView):
  template_name = "logout_complete.html"

# ReservationTopViewクラスはLoginRequiredMixinクラスとTemplateViewクラスを継承を継承し、
# 指定したテンプレート (reservation_top.html) を表示する
# ログインしていなければアクセスできない
class ReservationTopView(LoginRequiredMixin, TemplateView):
  template_name = "crud/reservation_top.html"

# ReservationCalenderViewクラスはLoginRequiredMixinクラスとTemplateViewクラスを継承を継承し、
# 指定したテンプレート (reservation_calender.html) を表示する
# ログインしていなければアクセスできない
class ReservationCalenderView(LoginRequiredMixin, TemplateView):
  template_name = "crud/reservation_calender.html"

# データの一覧表示に特化したListViewクラスを利用する
# LoginRequiredMixinクラスとListViewクラスを継承したクラスを定義
# ログインしていなければアクセスできない
class ReservationListView(LoginRequiredMixin, ListView):
  # 対象のModelクラスを指定する
  model = Reservation
  # 1ページに表示する数を指定
  # 1ページに3件表示するように指定
  paginate_by = 3

# 新規作成に特化したCreateViewを使用する
# LoginRequiredMixinクラスとCreateViewを継承したクラスを定義
# ログインしていなければアクセスできない
class ReservationCreateView(LoginRequiredMixin, CreateView):
  # 対象のModelクラスを指定する
  model = Reservation
  # 新規作成時にユーザが入力するフィールドを指定する
  # 全フィールドを指定する
  fields = '__all__'

# 編集に特化したUpdateViewクラスを利用する
# LoginRequiredMixinクラスとUpdateViewを継承したクラスを定義
# ログインしていなければアクセスできない
class ReservationUpdateView(LoginRequiredMixin, UpdateView):
  # 対象のModelクラスを指定する
  model = Reservation
  # 新規作成時にユーザが入力するフィールドを指定する
  # 全フィールドを指定する
  fields = '__all__'
  # 編集用のTemplateファイル名を指定する
  template_name_suffix = '_update_form'

# 削除に特化したDeleteViewクラスを利用する
# LoginRequiredMixinクラスとDeleteViewを継承したクラスを定義
# ログインしていなければアクセスできない
class ReservationDeleteView(LoginRequiredMixin, DeleteView):
  # 対象のModelクラスを指定する
  model = Reservation
  # 削除成功時に遷移するURLを指定
  # ここでは一覧画面を指定する
  success_url = reverse_lazy('list')

# データの詳細表示に特化したDetailViewクラスを利用する
# LoginRequiredMixinクラスとDetailViewを継承したクラスを定義
# ログインしていなければアクセスできない
class ReservationDetailView(LoginRequiredMixin, DetailView):
  # 対象のModelクラスを指定する
  model = Reservation

# ログインに特化したLoginViewクラスを利用する
# LoginViewクラスを継承したクラスを定義
class LoginView(LoginView):
  # デフォルトで用意されているAuthenticationFormを指定
  form_class = AuthenticationForm
  # Templateファイル名を指定
  template_name = 'login.html'

# ログアウトに特化したLogoutViewクラスを利用する
# LoginRequiredMixinクラスとLogoutViewクラスを継承したクラスを定義
# ログインしていなければアクセスできない
class LogoutView(LoginRequiredMixin, LogoutView):
  # Templateファイル名を指定する
  template_name = 'logout_complete.html'